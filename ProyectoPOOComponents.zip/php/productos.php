<?php
//funcion para agregar productos
function agregarproductos();
$claveproducto = $_POST["claveproducto"];
$nombreproducto = $_POST["nombreproducto"];
$descripcionproducto = $_POST["descripcionproducto"];
$precioproducto = $_POST["precioproducto"];

//insertar valores  en la tabla productos
$consulta = "INSERT INTO productos (claveproducto,nombreproducto,descripcionproducto,precioproducto) VALUES ('$claveproducto','$nombreproducto','$descripcionproducto','$precioproducto')"


?>  