<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <?php echo '<p>Hello World</p>'; ?> 

    <!--
    This script places a badge on your repl's full-browser view back to your repl's cover
    page. Try various colors for the theme: dark, light, red, orange, yellow, lime, green,
    teal, blue, blurple, magenta, pink!



  link usuarios:
    Emma:  https://replit.com/@emmanuel24?tab=repls

    Carlos:https://replit.com/@CarlosManuelM20?tab=repls
    -->
    <a href = "./html/registro.html">Registro</a>
    <a href= "./html/principal.html">Principal</a>
    <a href=   "./html/productoDetalles.html">Producto detalles</a>
    <a href=" ./html/carrito.html">Carrito</a>
    <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
  </body>
</html>

<br>
<br>
<br>
https://meet.google.com/ttz-iqpx-wiq?pli=1